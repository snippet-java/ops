'use strict';

const express = require('express');


// Constants
//Using ENV variable PORT set from Dockerfile to assign value to Constant PORT
const PORT = process.env.PORT;
const HOST = '0.0.0.0';

console.log(`Starting app `);

// App
const app = express();
console.log(`Constructing response `);
app.get('/', (req, res) => {
  res.send('Hello world once again\n');
});

app.listen(PORT, HOST);
console.log(`Running on http://${HOST}:${PORT}`);